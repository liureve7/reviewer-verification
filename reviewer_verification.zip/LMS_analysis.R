# Analysis specification for Tables 9-12 of the revised manuscript
# X: overall perceived affordances; W: perceived AI hallucination
# M: psychological ownership; Y: interaction intention
# Original environment: R 4.6.2, lavaan 0.7-3, modsem 1.0.24.
#
# Rscript LMS_analysis.R
#   Displays the archived aggregate bootstrap summary for review.
# Rscript LMS_analysis.R path/to/authorized_analysis_data.csv
#   Fits the baseline, main LMS, and three alternative models locally.
# Rscript LMS_analysis.R path/to/authorized_analysis_data.sav --bootstrap
#   Also draws 5,000 nonparametric bootstrap resamples. A CSV may also be used.
#
# The participant-level data are subject to a data-sharing agreement and are
# unavailable in this package. Re-estimation requires authorized access to
# the analysis data. The companion AMOS model and HTML report document the
# overall measurement model. The LMS analyses below were performed in R.
# This script reconstructs the analysis from the archived model definitions,
# estimation settings, and estimand functions. Outputs are aggregate only.

measurement_model <- '
  X =~ PA + SA + EA
  W =~ AH1 + AH2 + AH3
  M =~ PO_1 + PO_2 + PO_3 + PO_4
  Y =~ IW1 + IW2 + IW3 + IW4
  X ~~ W
'

models <- list(
  baseline = paste(measurement_model, 'M ~ X + W\nY ~ X + M'),
  main = paste(measurement_model, 'M ~ X + W + X:W\nY ~ X + M'),
  comparison_baseline = paste(measurement_model, 'M ~ X + W\nY ~ X + M + W'),
  comparison_1 = paste(measurement_model, 'M ~ X + W + X:W\nY ~ X + M + W'),
  comparison_2 = paste(measurement_model, 'M ~ X + W\nY ~ X + M + W + M:W'),
  comparison_3 = paste(measurement_model, 'M ~ X + W\nY ~ X + M + W + X:W')
)

read_analysis_data <- function(path) {
  # PA, SA and EA are previously computed means of five items per dimension.
  # Provide the final analysis variables with the original scoring and coding.
  extension <- tolower(tools::file_ext(path))
  data <- switch(extension,
    csv = utils::read.csv(path, check.names = FALSE, fileEncoding = 'UTF-8-BOM'),
    sav = haven::read_sav(I(readBin(path, 'raw', n = file.size(path)))),
    stop('Provide authorized analysis data in CSV or SPSS SAV format.')
  )
  required <- c('PA', 'SA', 'EA', paste0('AH', 1:3),
                paste0('PO_', 1:4), paste0('IW', 1:4))
  if (length(setdiff(required, names(data))) || anyDuplicated(names(data))) {
    stop('Expected unique columns PA, SA, EA, AH1-AH3, PO_1-PO_4 and IW1-IW4.')
  }
  data <- as.data.frame(data)[required]
  stopifnot(nrow(data) == 712L,
            all(vapply(data, function(column) is.numeric(column) &&
                         all(is.finite(column)), logical(1))))
  data
}

fit_baseline <- function(syntax, data) {
  lavaan::sem(syntax, data = data, estimator = 'ML', meanstructure = TRUE,
              fixed.x = FALSE, missing = 'listwise', std.lv = FALSE,
              optim.method = 'nlminb', information = 'expected')
}

fit_lms <- function(syntax, data, nodes) {
  modsem::modsem(syntax, data = data, method = 'lms', nodes = nodes,
                 algorithm = 'EMA', optimizer = 'nlminb',
                 center.data = FALSE, standardize.data = FALSE,
                 standardize.out = FALSE, mean.observed = TRUE,
                 auto.fix.first = TRUE, adaptive.quad = TRUE,
                 convergence.abs = 1e-4, convergence.rel = 1e-10,
                 convergence.grad = 1e-3, verbose = FALSE)
}

get_parameter <- function(parameters, lhs, op, rhs) {
  row <- parameters[parameters$lhs == lhs & parameters$op == op &
                      parameters$rhs %in% rhs, , drop = FALSE]
  stopifnot(nrow(row) == 1L, is.finite(row$est))
  row
}

conditional_effects <- function(fit) {
  p <- as.data.frame(modsem::parameter_estimates(fit))
  a <- get_parameter(p, 'M', '~', 'X')$est
  a3 <- get_parameter(p, 'M', '~', c('X:W', 'W:X'))$est
  b <- get_parameter(p, 'Y', '~', 'M')$est
  w_mean <- unname(modsem::modsem_inspect(fit, 'mean.lv')['W', 1L])
  w_var <- get_parameter(p, 'W', '~~', 'W')$est
  stopifnot(is.finite(w_mean), w_var > 0)
  w <- w_mean + c(-1, 0, 1) * sqrt(w_var)
  slope <- a + a3 * w
  list(w = w, slope = slope,
       statistics = c(interaction = a3, indirect_low = slope[1L] * b,
                      indirect_mean = slope[2L] * b, indirect_high = slope[3L] * b,
                      moderated_mediation_index = a3 * b))
}

bootstrap_statistic <- function(fit) {
  if (!isTRUE(modsem::modsem_inspect(fit, 'convergence'))) {
    return(stats::setNames(rep(NA_real_, 5L), names(archived_estimates)))
  }
  # The statistic recomputes the latent W mean and SD in every resample.
  conditional_effects(fit)$statistics
}

run_bootstrap <- function(fit, batches = 10L, draws_per_batch = 500L) {
  # Original run: 10 batches of 500, with seeds 202611151 through 202611160.
  # Refit each case resample, starting from the full-sample estimates.
  batches <- lapply(seq_len(batches), function(i) {
    message('Bootstrap batch ', i, ': ', draws_per_batch, ' resamples')
    set.seed(202611150L + i)
    modsem::bootstrap_modsem(
      fit, FUN = bootstrap_statistic, R = draws_per_batch,
      type = 'nonparametric', optimize = FALSE, calc.se = FALSE,
      algorithm = fit$args$algorithm,
      convergence.abs = fit$args$convergence.abs,
      convergence.rel = fit$args$convergence.rel,
      convergence.grad = fit$args$convergence.grad, verbose = FALSE
    )
  })
  do.call(rbind, batches)
}

bootstrap_intervals <- function(draws) {
  valid <- rowSums(!is.finite(draws)) == 0L
  stopifnot(any(valid))
  message('Usable bootstrap fits: ', sum(valid), '/', nrow(draws))
  t(apply(draws[valid, , drop = FALSE], 2L, stats::quantile,
          probs = c(0.025, 0.975), type = 7, names = FALSE))
}

# A read-only reference transcribed from the fitted main model and the
# empirical quantiles of all 5,000 archived converged bootstrap draws.
# Estimates and interval limits are rounded here for display.
archived_estimates <- c(interaction = -0.1813664, indirect_low = 0.497259,
                        indirect_mean = 0.348134, indirect_high = 0.199009,
                        moderated_mediation_index = -0.1169803)
archived_intervals <- cbind(
  lower_95 = c(-0.2500398, 0.3372857, 0.2358953, 0.1119220, -0.1768778),
  upper_95 = c(-0.1205602, 0.6759115, 0.4793778, 0.3068441, -0.0702687)
)

model_information <- function(fit, n) {
  if (inherits(fit, 'lavaan')) {
    return(as.numeric(lavaan::fitMeasures(fit, c('logl', 'aic', 'bic', 'npar'))))
  }
  ll <- as.numeric(fit$logLik)
  k <- length(fit$coefs.free)
  c(ll, -2 * ll + 2 * k, -2 * ll + log(n) * k, k)
}

information_table <- function(fits, n) {
  info <- t(vapply(fits, model_information, numeric(4L), n = n))
  colnames(info) <- c('log_likelihood', 'AIC', 'BIC', 'parameters')
  info
}

likelihood_ratio <- function(info) {
  chi_sq <- 2 * (info[-1L, 'log_likelihood'] - info[1L, 'log_likelihood'])
  df <- info[-1L, 'parameters'] - info[1L, 'parameters']
  cbind(chi_sq = chi_sq, df = df, p = stats::pchisq(chi_sq, df, lower.tail = FALSE))
}

structural_paths <- function(fit) {
  p <- as.data.frame(modsem::parameter_estimates(fit))
  paths <- p[p$op == '~', c('lhs', 'rhs', 'est', 'std.error', 'z.value', 'p.value')]
  latent_sd <- sqrt(diag(modsem::modsem_inspect(fit, 'cov.lv')))
  predictor_sd <- latent_sd[paths$rhs]
  predictor_sd[paths$rhs %in% c('X:W', 'W:X')] <- latent_sd['X'] * latent_sd['W']
  paths$beta <- paths$est * predictor_sd / latent_sd[paths$lhs]
  paths
}

run_analysis <- function(data, bootstrap = FALSE) {
  baseline <- fit_baseline(models$baseline, data)
  main <- fit_lms(models$main, data, nodes = 24L)
  stopifnot(lavaan::lavInspect(baseline, 'converged'),
            isTRUE(modsem::modsem_inspect(main, 'convergence')))
  cat('\nTable 9: baseline fit and likelihood-ratio comparison\n')
  print(lavaan::fitMeasures(baseline, c('chisq', 'df', 'cfi', 'tli', 'rmsea', 'srmr')))
  main_info <- information_table(list(baseline = baseline, LMS = main), nrow(data))
  print(main_info)
  print(likelihood_ratio(main_info))

  cat('\nTable 10: LMS structural paths\n')
  print(structural_paths(main), row.names = FALSE)

  comparison_base <- fit_baseline(models$comparison_baseline, data)
  comparisons <- lapply(models[paste0('comparison_', 1:3)], fit_lms,
                        data = data, nodes = 32L)
  stopifnot(lavaan::lavInspect(comparison_base, 'converged'),
            all(vapply(comparisons, function(fit) {
              isTRUE(modsem::modsem_inspect(fit, 'convergence'))
            }, logical(1))))
  alt_info <- information_table(c(list(baseline = comparison_base), comparisons), nrow(data))
  cat('\nTable 11: alternative interaction paths, each including W -> Y\n')
  print(alt_info)
  print(likelihood_ratio(alt_info))
  print(do.call(rbind, lapply(comparisons, function(fit) {
    p <- as.data.frame(modsem::parameter_estimates(fit))
    path <- p[p$op == '~' & grepl(':', p$rhs, fixed = TRUE),
              c('lhs', 'rhs', 'est', 'std.error', 'z.value', 'p.value')]
    critical <- stats::qnorm(0.975)
    path$lower_95 <- path$est - critical * path$std.error
    path$upper_95 <- path$est + critical * path$std.error
    path
  })), row.names = FALSE)

  result <- conditional_effects(main)
  cat('\nSimple slopes at low, mean and high W\n')
  print(cbind(W = result$w, simple_slope = result$slope))
  cat('\nTable 12: conditional indirect effects and moderated mediation index\n')
  print(result$statistics)
  if (bootstrap) {
    print(cbind(estimate = result$statistics,
                bootstrap_intervals(run_bootstrap(main))))
  }
  invisible(result)
}

if (sys.nframe() == 0L) {
  options(digits = 8L)
  args <- commandArgs(trailingOnly = TRUE)
  if (!length(args)) {
    cat('Archived aggregate estimates and 95% percentile bootstrap intervals\n')
    print(cbind(estimate = archived_estimates, archived_intervals))
  } else {
    stopifnot(length(args) <= 2L, length(args) == 1L || args[2L] == '--bootstrap')
    run_analysis(read_analysis_data(args[1L]), bootstrap = length(args) == 2L)
  }
}
